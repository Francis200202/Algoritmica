#ifndef METODOS_HPP
#define METODOS_HPP

#include <iostream>
#include "serietemporal.hpp"

//Metodo 1
void metodo1();

#endif